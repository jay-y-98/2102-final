export const questions = [
    'How much ATK does the blue eyes white dragon have?',
    'What month has 28 days (Please type the full name)',
    'What is Yugis boss monster called?',
    'How many tributes for a level 7?',
    'What level is Relinquished?',
    'What class is this for? (CSE____)',
    'This is literally free points, just leave it blank',
    'Does Pot of Greed really draw two cards from the top of your deck, and add it to your hand? (y/n)'
]

export const correctAnswers = [
    '3000',
    'February',
    'Dark Magician',
    '2',
    '1',
    '2102',
    '',
    'y'
];

